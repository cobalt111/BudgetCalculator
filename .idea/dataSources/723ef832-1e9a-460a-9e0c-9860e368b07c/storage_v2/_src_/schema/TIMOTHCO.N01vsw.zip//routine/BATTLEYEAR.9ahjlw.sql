create FUNCTION battleYear(inputName Battles.battleName%TYPE) RETURN Battles.battleYr%TYPE AS
    resultYr Battles.battleYr%TYPE;
    BEGIN
        SELECT battleYr INTO resultYr FROM Battles WHERE battleName = inputName;
        RETURN resultYr;
    end;
/

