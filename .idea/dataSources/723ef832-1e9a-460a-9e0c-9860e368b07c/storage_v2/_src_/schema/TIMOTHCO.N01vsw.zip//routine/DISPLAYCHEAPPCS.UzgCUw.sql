create procedure displayCheapPCs AS
begin
    for pcRow in (select model, price from pc where price < 800) loop
        dbms_output.put_line(pcRow.model || ' has a price of ' || pcRow.price);
    end loop;
end;
/

