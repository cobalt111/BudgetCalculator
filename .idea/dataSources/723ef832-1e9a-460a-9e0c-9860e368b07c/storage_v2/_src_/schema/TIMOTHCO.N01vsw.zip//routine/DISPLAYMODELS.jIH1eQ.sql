create procedure displayModels (maker Product.maker%type) AS
	begin
		for x in (select product.maker, pc.model, pc.price from PC, Product where pc.model = product.model and Product.maker = 'A') loop
			if (x.maker = maker) then
				dbms_output.put_line(x.model);
			end if;
		end loop;
	end;
/

