create PROCEDURE insertOutcomes(inputShipName Ships.shipName%TYPE, inputBattleName Battles.battleName%TYPE, inputOutcome Outcomes.outcome%TYPE) AS
    bName Battles.battleName%TYPE;
    sName Ships.shipName%TYPE;
    BEGIN
        SELECT COUNT(battleName) INTO bName FROM Battles WHERE battleName = inputBattleName;
        IF (bName = 0) THEN
            INSERT INTO Battles VALUES (inputBattleName, default);
        END IF;
        SELECT COUNT(shipName) INTO sName FROM Ships WHERE shipName = inputShipName;
        IF (sName = 0) THEN
            INSERT INTO Ships VALUES (inputShipName, default, default);
        END IF;
    END;
/

