create procedure lessThanPrice (inputPrice PC.price%type) AS
--    pcModel PC.model%type;
begin
    for pcModel in (select model from PC where price < inputPrice) loop
        dbms_output.put_line('Model : ' || pcModel.model);
    end loop;
end;
/

