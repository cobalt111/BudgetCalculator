create procedure pcPriceDisplay (pcModel PC.model%type) AS -- takes a parameter named pcModel)
    pcPrice PC.price%type;
    pcHD PC.hd%type
begin
    pcModel := 1001; -- := is the assignment operator
    select price into pcPrice, pcHD into pcHD from pc where model = 1001;
    dbms_output.put_line('PC model ' || pcModel || ' has a price of ' || pcPrice || ' and hd of ' || pcHD);
end;
/

