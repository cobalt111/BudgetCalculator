create PROCEDURE printBattlesForShip (shipName Ships.shipName%TYPE) AS
    BEGIN
        FOR shipBattle IN (SELECT battle FROM Outcomes WHERE ship = shipName) LOOP
            dbms_output.put_line('This ship was in battle: ' || shipBattle.battle);
        END LOOP;
    END;
/

