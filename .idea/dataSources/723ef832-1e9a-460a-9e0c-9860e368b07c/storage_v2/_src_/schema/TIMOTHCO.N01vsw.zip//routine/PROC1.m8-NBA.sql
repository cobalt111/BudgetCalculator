create procedure proc1 (makerInput Product.maker%type) AS
declare
	cursor pcCur (m Product.maker%type) is (select model from pc, product where maker = m and pc.model = product.model);
	pcModel PC.model%type;
begin
	open pcCur(makerInput);
	loop
		fetch pcCur into pcModel;
		exit when pcCursor%NOTFOUND;
		dbms_output.put_line(pcModel);
	end loop;
	close pcCur;
end;
/

