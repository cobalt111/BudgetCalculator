create PROCEDURE shipsByCountry (inputCountryName Classes.country%TYPE) AS
    BEGIN
        FOR ship IN (SELECT shipName FROM Ships JOIN Classes ON Ships.shipClass = Classes.className WHERE country = inputCountryName) LOOP
            dbms_output.put_line('Ship made by ' || inputCountryName || ': ' || ship.shipName);
        END LOOP;
    END;
/

