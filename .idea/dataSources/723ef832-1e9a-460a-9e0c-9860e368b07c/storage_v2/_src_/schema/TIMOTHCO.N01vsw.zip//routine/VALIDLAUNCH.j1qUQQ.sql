create PROCEDURE validLaunch(sName Ships.shipName%TYPE) AS
    BEGIN
        FOR currentShip IN 
        (SELECT shipName, launchYr, battleYr 
        FROM Ships JOIN (SELECT battleYr, ship FROM Outcomes JOIN Battles ON Outcomes.battle = Battles.battleName) subQuery ON Ships.shipName = subQuery.ship 
        WHERE shipName = sname) 
        LOOP
            IF (currentShip.launchYr > currentShip.battleYr) THEN
                UPDATE Ships SET launchYr = null WHERE currentShip.shipName = Ships.shipName;
                dbms_output.put_line(sName || ' had a invalid launchYr and it is now set to null');
            ELSE
                dbms_output.put_line(sName || ' has a valid launchYr');
            END IF;
        END LOOP;
    END;
/

