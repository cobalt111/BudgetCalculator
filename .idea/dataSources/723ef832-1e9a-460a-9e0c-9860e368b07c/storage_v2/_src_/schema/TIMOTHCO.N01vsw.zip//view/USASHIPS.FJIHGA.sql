create view USASHIPS as
  SELECT shipName, shipClass, numGuns, bore, displacement
    FROM Ships JOIN Classes ON Ships.shipClass = Classes.className
    WHERE country = 'USA'
/

